package com.example.option1inventoryapp_kaloudis;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CustomAdapterRecycleView extends RecyclerView.Adapter<CustomAdapterRecycleView.MyViewHolder> {

    private Context context;
    Activity activity;

    private ArrayList itemID, itemName, itemQuantity, itemLocation;
    Animation translate_anim;


    CustomAdapterRecycleView(Activity activity, Context context, ArrayList itemID, ArrayList itemName, ArrayList itemQuantity, ArrayList itemLocation){
        this.activity = activity;
        this.context = context;
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.itemLocation = itemLocation;

    }

    @NonNull
    @Override
    public CustomAdapterRecycleView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.first_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.itemID.setText(String.valueOf(itemID.get(position)));
        holder.itemName.setText(String.valueOf(itemName.get(position)));
        holder.itemQuantity.setText(String.valueOf(itemQuantity.get(position)));
        holder.itemLocation.setText(String.valueOf(itemLocation.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateInventory.class);
                intent.putExtra("itemID", String.valueOf(itemID.get(holder.getAdapterPosition())));
                intent.putExtra("itemName", String.valueOf(itemName.get(holder.getAdapterPosition())));
                intent.putExtra("itemQuantity", String.valueOf(itemQuantity.get(holder.getAdapterPosition())));
                intent.putExtra("itemLocation", String.valueOf(itemLocation.get(holder.getAdapterPosition())));
                activity.startActivityForResult(intent, 1);
            }
        });


    }


    @Override
    public int getItemCount() {
        return itemID.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView itemID, itemName, itemQuantity, itemLocation;
        RelativeLayout mainLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemID = itemView.findViewById(R.id.itemID);
            itemName = itemView.findViewById(R.id.itemName2);
            itemQuantity = itemView.findViewById(R.id.itemQuantity2);
            itemLocation = itemView.findViewById(R.id.itemLocation2);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);


        }
    }
}
