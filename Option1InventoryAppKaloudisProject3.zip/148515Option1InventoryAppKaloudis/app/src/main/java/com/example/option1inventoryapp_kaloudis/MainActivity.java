package com.example.option1inventoryapp_kaloudis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    EditText username, password, repassword, phoneNumber;
    MaterialButton registerButton2, loginButton2;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username2);
        password = (EditText) findViewById(R.id.password2);
        repassword = (EditText) findViewById(R.id.password3);
        phoneNumber = (EditText) findViewById(R.id.phoneNumber);
        registerButton2 = (MaterialButton) findViewById(R.id.registerButton2);
        loginButton2 = (MaterialButton) findViewById(R.id.loginButton2);
        DB = new DBHelper(this);



        registerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();
                String phone = phoneNumber.getText().toString();


                if (user.equals("") || pass.equals("") || repass.equals("") || phone.equals("")) {
                    Toast.makeText(MainActivity.this,"Please enter all fields.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pass.equals(repass)) {
                        Boolean checkUser = DB.checkUsername(user);
                        if (checkUser == false){
                            Boolean insert = DB.insertData(user, pass, phone);
                            if (insert == true) {
                                Toast.makeText(MainActivity.this,"Registered Successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(MainActivity.this,"Registration Failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(MainActivity.this,"User already exists. Please sign in.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(MainActivity.this,"Passwords are not matching.", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        loginButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                startActivity(intent);
            }
        });


    }
    public void EmptyEditTextAfterDataInsert(){
        username.getText().clear();
        phoneNumber.getText().clear();
        password.getText().clear();
        repassword.getText().clear();
    }
}