package com.example.option1inventoryapp_kaloudis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.button.MaterialButton;

public class AddInventory extends AppCompatActivity {

    EditText itemName, itemQuantity, itemLocation;
    MaterialButton addButton2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory);

        itemName = findViewById(R.id.itemName);
        itemQuantity = findViewById(R.id.itemQuantity);
        itemLocation = findViewById(R.id.itemLocation);
        addButton2 = findViewById(R.id.addButton2);

        addButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelperAddInventory myDB = new DBHelperAddInventory(AddInventory.this);
                myDB.addItem(itemName.getText().toString(),
                        Integer.valueOf(itemQuantity.getText().toString()),
                        itemLocation.getText().toString());

            }
        });

    }
}