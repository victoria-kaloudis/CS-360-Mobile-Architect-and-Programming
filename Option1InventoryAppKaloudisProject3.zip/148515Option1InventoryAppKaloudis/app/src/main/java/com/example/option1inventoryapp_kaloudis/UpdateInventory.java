package com.example.option1inventoryapp_kaloudis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class UpdateInventory extends AppCompatActivity {

    EditText itemName3, itemQuantity3, itemLocation3;
    MaterialButton updateButton3, deleteButton3;
    String ID, itemName, itemQuantity, itemLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_inventory);

        itemName3 = findViewById(R.id.itemName3);
        itemQuantity3 = findViewById(R.id.itemQuantity3);
        itemLocation3 = findViewById(R.id.itemLocation3);
        updateButton3 = findViewById(R.id.updateButton3);
        deleteButton3 = findViewById(R.id.deleteButton3);
        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if (ab != null){
            ab.setTitle(itemName);
        }

        updateButton3.setOnClickListener(v -> {
            DBHelperAddInventory myDB = new DBHelperAddInventory(UpdateInventory.this);
            itemName = itemName3.getText().toString().trim();
            itemQuantity = itemQuantity3.getText().toString().trim();
            itemLocation = itemLocation3.getText().toString().trim();
            myDB.updateData(ID, itemName, itemQuantity, itemLocation);
        });

        deleteButton3.setOnClickListener(v -> {
            confirmDialogue();
        });

    }

    void getAndSetIntentData(){
        if (getIntent().hasExtra("itemID") && getIntent().hasExtra("itemName") && getIntent().hasExtra("itemQuantity") && getIntent().hasExtra("itemLocation")){
            ID = getIntent().getStringExtra("itemID");
            itemName = getIntent().getStringExtra("itemName");
            itemQuantity = getIntent().getStringExtra("itemQuantity");
            itemLocation = getIntent().getStringExtra("itemLocation");

            itemName3.setText(itemName);
            itemQuantity3.setText(itemQuantity);
            itemLocation3.setText(itemLocation);

        }
        else {
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialogue(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + itemName + " ?");
        builder.setMessage("Are you sure you want to delete " + itemName + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelperAddInventory myDB = new DBHelperAddInventory(UpdateInventory.this);
                myDB.deleteOneRow(ID);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create().show();
    }



}