package com.example.option1inventoryapp_kaloudis;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class SMS extends AppCompatActivity {


    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        MaterialButton goToInventoryButton = (MaterialButton)  findViewById(R.id.goToInventory);

        goToInventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), InventoryListScreen.class);
                startActivity(intent);
            }
        });


        int sms = ActivityCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS);
        //check if the permission is not granted to send sms
        if (sms != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 999);
        }
        else {
            accessApp();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode==999 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
            accessApp();
        }
        else if (requestCode==999 && grantResults[0]!=PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "Permission to send SMS messages is required.", Toast.LENGTH_SHORT).show();
        }
    }

    public void accessApp() {
        Toast.makeText(this, "You will now receive automated system messages.", Toast.LENGTH_SHORT).show();
    }



}